package com.parttime.backstage.service.impl;

import java.util.List;
import com.parttime.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.parttime.backstage.mapper.SysSortMapper;
import com.parttime.backstage.domain.SysSort;
import com.parttime.backstage.service.ISysSortService;

/**
 * 分类Service业务层处理
 * 
 * @author parttime
 * @date 2021-05-26
 */
@Service
public class SysSortServiceImpl implements ISysSortService 
{
    @Autowired
    private SysSortMapper sysSortMapper;

    /**
     * 查询分类
     * 
     * @param sortId 分类ID
     * @return 分类
     */
    @Override
    public SysSort selectSysSortById(Long sortId)
    {
        return sysSortMapper.selectSysSortById(sortId);
    }

    /**
     * 查询分类列表
     * 
     * @param sysSort 分类
     * @return 分类
     */
    @Override
    public List<SysSort> selectSysSortList(SysSort sysSort)
    {
        return sysSortMapper.selectSysSortList(sysSort);
    }

    /**
     * 新增分类
     * 
     * @param sysSort 分类
     * @return 结果
     */
    @Override
    public int insertSysSort(SysSort sysSort)
    {
        sysSort.setCreateTime(DateUtils.getNowDate());
        return sysSortMapper.insertSysSort(sysSort);
    }

    /**
     * 修改分类
     * 
     * @param sysSort 分类
     * @return 结果
     */
    @Override
    public int updateSysSort(SysSort sysSort)
    {
        sysSort.setUpdateTime(DateUtils.getNowDate());
        return sysSortMapper.updateSysSort(sysSort);
    }

    /**
     * 批量删除分类
     * 
     * @param sortIds 需要删除的分类ID
     * @return 结果
     */
    @Override
    public int deleteSysSortByIds(Long[] sortIds)
    {
        return sysSortMapper.deleteSysSortByIds(sortIds);
    }

    /**
     * 删除分类信息
     * 
     * @param sortId 分类ID
     * @return 结果
     */
    @Override
    public int deleteSysSortById(Long sortId)
    {
        return sysSortMapper.deleteSysSortById(sortId);
    }
}
