package com.parttime.backstage.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.parttime.common.annotation.Excel;
import com.parttime.common.core.domain.BaseEntity;

/**
 * 分类对象 sys_sort
 * 
 * @author parttime
 * @date 2021-05-26
 */
public class SysSort extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 分类ID */
    private Long sortId;

    /** 分类名 */
    @Excel(name = "分类名")
    private String className;

    /** 分类图标 */
    @Excel(name = "分类图标")
    private String classIcon;

    /** 路由  */
    @Excel(name = "路由 ")
    private String address;

    /** 是否启用(0:未启用，1：启用) */
    @Excel(name = "是否启用")
    private String state;

    /** 序号 */
    @Excel(name = "序号")
    private Long number;

    /** 备用字段 */
    @Excel(name = "备用字段")
    private String spare;

    public void setSortId(Long sortId) 
    {
        this.sortId = sortId;
    }

    public Long getSortId() 
    {
        return sortId;
    }
    public void setClassName(String className) 
    {
        this.className = className;
    }

    public String getClassName() 
    {
        return className;
    }
    public void setClassIcon(String classIcon) 
    {
        this.classIcon = classIcon;
    }

    public String getClassIcon() 
    {
        return classIcon;
    }
    public void setAddress(String address) 
    {
        this.address = address;
    }

    public String getAddress() 
    {
        return address;
    }
    public void setState(String state) 
    {
        this.state = state;
    }

    public String getState() 
    {
        return state;
    }
    public void setNumber(Long number) 
    {
        this.number = number;
    }

    public Long getNumber() 
    {
        return number;
    }
    public void setSpare(String spare) 
    {
        this.spare = spare;
    }

    public String getSpare() 
    {
        return spare;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("sortId", getSortId())
            .append("className", getClassName())
            .append("classIcon", getClassIcon())
            .append("address", getAddress())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("state", getState())
            .append("number", getNumber())
            .append("spare", getSpare())
            .toString();
    }
}
