import request from '@/utils/request'

// 查询分类列表
export function listSort(query) {
  return request({
    url: '/parttime-backstage/sort/list',
    method: 'get',
    params: query
  })
}

// 查询分类详细
export function getSort(sortId) {
  return request({
    url: '/parttime-backstage/sort/' + sortId,
    method: 'get'
  })
}

// 新增分类
export function addSort(data) {
  return request({
    url: '/parttime-backstage/sort',
    method: 'post',
    data: data
  })
}

// 修改分类
export function updateSort(data) {
  return request({
    url: '/parttime-backstage/sort',
    method: 'put',
    data: data
  })
}

// 删除分类
export function delSort(sortId) {
  return request({
    url: '/parttime-backstage/sort/' + sortId,
    method: 'delete'
  })
}

// 导出分类
export function exportSort(query) {
  return request({
    url: '/parttime-backstage/sort/export',
    method: 'get',
    params: query
  })
}
