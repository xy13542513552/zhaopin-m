package com.parttime.backstage.mapper;

import java.util.List;
import com.parttime.backstage.domain.Banner;

/**
 * bannerMapper接口
 * 
 * @author parttime
 * @date 2021-05-26
 */
public interface BannerMapper 
{
    /**
     * 查询banner
     * 
     * @param bannerTabId bannerID
     * @return banner
     */
    public Banner selectBannerById(Long bannerTabId);

    /**
     * 查询banner列表
     * 
     * @param banner banner
     * @return banner集合
     */
    public List<Banner> selectBannerList(Banner banner);

    /**
     * 新增banner
     * 
     * @param banner banner
     * @return 结果
     */
    public int insertBanner(Banner banner);

    /**
     * 修改banner
     * 
     * @param banner banner
     * @return 结果
     */
    public int updateBanner(Banner banner);

    /**
     * 删除banner
     * 
     * @param bannerTabId bannerID
     * @return 结果
     */
    public int deleteBannerById(Long bannerTabId);

    /**
     * 批量删除banner
     * 
     * @param bannerTabIds 需要删除的数据ID
     * @return 结果
     */
    public int deleteBannerByIds(Long[] bannerTabIds);
}
