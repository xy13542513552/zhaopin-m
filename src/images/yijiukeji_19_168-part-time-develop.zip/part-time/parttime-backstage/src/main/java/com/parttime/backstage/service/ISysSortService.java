package com.parttime.backstage.service;

import java.util.List;
import com.parttime.backstage.domain.SysSort;

/**
 * 分类Service接口
 * 
 * @author parttime
 * @date 2021-05-26
 */
public interface ISysSortService 
{
    /**
     * 查询分类
     * 
     * @param sortId 分类ID
     * @return 分类
     */
    public SysSort selectSysSortById(Long sortId);

    /**
     * 查询分类列表
     * 
     * @param sysSort 分类
     * @return 分类集合
     */
    public List<SysSort> selectSysSortList(SysSort sysSort);

    /**
     * 新增分类
     * 
     * @param sysSort 分类
     * @return 结果
     */
    public int insertSysSort(SysSort sysSort);

    /**
     * 修改分类
     * 
     * @param sysSort 分类
     * @return 结果
     */
    public int updateSysSort(SysSort sysSort);

    /**
     * 批量删除分类
     * 
     * @param sortIds 需要删除的分类ID
     * @return 结果
     */
    public int deleteSysSortByIds(Long[] sortIds);

    /**
     * 删除分类信息
     * 
     * @param sortId 分类ID
     * @return 结果
     */
    public int deleteSysSortById(Long sortId);
}
