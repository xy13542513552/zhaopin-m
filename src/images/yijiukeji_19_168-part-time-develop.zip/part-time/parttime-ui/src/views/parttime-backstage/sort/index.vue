<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryForm" :inline="true" v-show="showSearch" label-width="68px">
<!--      <el-form-item label="分类名" prop="className">
        <el-input
          v-model="queryParams.className"
          placeholder="请输入分类名"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="分类图标" prop="classIcon">
        <el-input
          v-model="queryParams.classIcon"
          placeholder="请输入分类图标"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="路由 " prop="address">
        <el-input
          v-model="queryParams.address"
          placeholder="请输入路由 "
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="是否启用(0:未启用，1：启用)" prop="state">
        <el-input
          v-model="queryParams.state"
          placeholder="请输入是否启用(0:未启用，1：启用)"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>-->
      <el-form-item label="序号" prop="number">
        <el-input
          v-model="queryParams.number"
          placeholder="请输入序号"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="备用字段" prop="spare">
        <el-input
          v-model="queryParams.spare"
          placeholder="请输入备用字段"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="el-icon-search" size="mini" @click="handleQuery">搜索</el-button>
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['system:sort:add']"
        >新增</el-button>
      </el-col>
      <right-toolbar :showSearch.sync="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="sortList"
      row-key="sortId"
      default-expand-all
      :tree-props="{children: 'children', hasChildren: 'hasChildren'}"
    >
      <el-table-column label="分类名" prop="className" :show-overflow-tooltip="true"/>
      <el-table-column label="分类图标" align="center" prop="classIcon" />
      <el-table-column label="路由 " align="center" prop="address" :show-overflow-tooltip="true"/>
      <el-table-column label="是否启用" align="center" >
        <template slot-scope="scope">
          <el-switch
            style="display: block"
            v-model="scope.row.state"
            @change="switchSubmit(scope.row)"
            active-value="0"
            inactive-value="1"
            active-text="开"
            inactive-text="关">
          </el-switch>

        </template>
      </el-table-column>
      <el-table-column label="序号" align="center" prop="number" />
      <el-table-column label="备用字段" align="center" prop="spare" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="text"
            icon="el-icon-edit"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:sort:edit']"
          >修改</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-plus"
            @click="handleAdd(scope.row)"
            v-hasPermi="['system:sort:add']"
          >新增</el-button>
          <el-button
            size="mini"
            type="text"
            icon="el-icon-delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:sort:remove']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 添加或修改分类对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="500px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="分类名" prop="className">
          <el-input v-model="form.className" placeholder="请输入分类名" />
        </el-form-item>
        <el-form-item label="分类图标" prop="classIcon">
          <el-input v-model="form.classIcon" placeholder="请输入分类图标" />
<!--          <el-upload
            class="upload-demo"
            action="https://jsonplaceholder.typicode.com/posts/"
            multiple
            :limit="3"
            :on-preview="handleExceed"
            :on-exceed="handleExceed"
            :file-list="fileUrl">
            <el-button size="small" type="primary">点击上传</el-button>
            <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
          </el-upload>-->
        </el-form-item>
        <el-form-item label="路由 " prop="address">
          <el-input v-model="form.address" placeholder="请输入路由 " />
        </el-form-item>
        <el-form-item label="是否启用(0:未启用，1：启用)" prop="state">
          <el-input v-model="form.state" placeholder="请输入是否启用" />
        </el-form-item>
        <el-form-item label="序号" prop="number">
          <el-input v-model="form.number" placeholder="请输入序号" />
        </el-form-item>
        <el-form-item label="备用字段" prop="spare">
          <treeselect v-model="form.spare" :options="sortOptions" :normalizer="normalizer" placeholder="请选择备用字段" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listSort, getSort, delSort, addSort, updateSort, exportSort } from "@/api/parttime-backstage/sort";
import Treeselect from "@riophae/vue-treeselect";
import "@riophae/vue-treeselect/dist/vue-treeselect.css";

export default {
  name: "Sort",
  components: {
    Treeselect
  },
  data() {
    return {
      // 遮罩层
      loading: true,
      // 显示搜索条件
      showSearch: true,
      // 分类表格数据
      sortList: [],
      // 分类树选项
      sortOptions: [],
      // 弹出层标题
      title: "",
      test:true,
      // 是否显示弹出层
      open: false,
      fileUrl:[],
      // 查询参数
      queryParams: {
        className: null,
        classIcon: null,
        address: null,
        state: null,
        number: null,
        spare: null
      },
      // 表单参数
      form: {},
      // 表单校验
      rules: {
        className: [
          { required: true, message: "分类名不能为空", trigger: "blur" }
        ],
        classIcon: [
          { required: true, message: "分类图标不能为空", trigger: "blur" }
        ],
        address: [
          { required: true, message: "路由 不能为空", trigger: "blur" }
        ],
        number: [
          { required: true, message: "序号不能为空", trigger: "blur" }
        ],
      }
    };
  },
  created() {
    this.getList();
  },
  methods: {
    /** 查询分类列表 */
    getList() {
      this.loading = true;

      listSort(this.queryParams).then(response => {
        this.sortList = this.handleTree(response.data, "sortId", "spare");
        this.loading = false;
      });
    },
    /*switchState(val){

      if(val=="1") {
        return true;
      }else {
        return false;
      }
    },*/
    switchSubmit(row){
      this.form=row;
      updateSort(this.form).then(response => {
        this.msgSuccess("修改成功");
        this.open = false;
        this.getList();
      });

    },
    handleExceed(files, fileList) {
      console.log(files);
      this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },
    /** 转换分类数据结构 */
    normalizer(node) {
      if (node.children && !node.children.length) {
        delete node.children;
      }
      return {
        id: node.sortId,
        label: node.className,
        children: node.children
      };
    },
    /** 查询分类下拉树结构 */
    getTreeselect() {
      listSort().then(response => {
        this.sortOptions = [];
        const data = { sortId: 0, className: '顶级节点', children: [] };
        data.children = this.handleTree(response.data, "sortId", "spare");
        this.sortOptions.push(data);
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        sortId: null,
        className: null,
        classIcon: null,
        address: null,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        state: null,
        number: null,
        spare: null
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    /** 新增按钮操作 */
    handleAdd(row) {
      this.reset();
      this.getTreeselect();
      if (row != null && row.sortId) {
        this.form.spare = row.sortId;
      } else {
        this.form.spare = 0;
      }
      this.open = true;
      this.title = "添加分类";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      this.getTreeselect();
      if (row != null) {
        this.form.spare = row.sortId;
      }
      getSort(row.sortId).then(response => {
        this.form = response.data;
        this.open = true;
        this.title = "修改分类";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (this.form.sortId != null) {
            updateSort(this.form).then(response => {
              this.msgSuccess("修改成功");
              this.open = false;
              this.getList();
            });
          } else {
            addSort(this.form).then(response => {
              this.msgSuccess("新增成功");
              this.open = false;
              this.getList();
            });
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      this.$confirm('是否确认删除分类编号为"' + row.sortId + '"的数据项?', "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(function() {
        return delSort(row.sortId);
      }).then(() => {
        this.getList();
        this.msgSuccess("删除成功");
      })
    }
  }
};
</script>
