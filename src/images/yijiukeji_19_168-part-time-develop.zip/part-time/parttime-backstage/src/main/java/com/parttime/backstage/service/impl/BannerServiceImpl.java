package com.parttime.backstage.service.impl;

import java.util.List;
import com.parttime.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.parttime.backstage.mapper.BannerMapper;
import com.parttime.backstage.domain.Banner;
import com.parttime.backstage.service.IBannerService;

/**
 * bannerService业务层处理
 * 
 * @author parttime
 * @date 2021-05-26
 */
@Service
public class BannerServiceImpl implements IBannerService 
{
    @Autowired
    private BannerMapper bannerMapper;

    /**
     * 查询banner
     * 
     * @param bannerTabId bannerID
     * @return banner
     */
    @Override
    public Banner selectBannerById(Long bannerTabId)
    {
        return bannerMapper.selectBannerById(bannerTabId);
    }

    /**
     * 查询banner列表
     * 
     * @param banner banner
     * @return banner
     */
    @Override
    public List<Banner> selectBannerList(Banner banner)
    {
        return bannerMapper.selectBannerList(banner);
    }

    /**
     * 新增banner
     * 
     * @param banner banner
     * @return 结果
     */
    @Override
    public int insertBanner(Banner banner)
    {
        banner.setCreateTime(DateUtils.getNowDate());
        return bannerMapper.insertBanner(banner);
    }

    /**
     * 修改banner
     * 
     * @param banner banner
     * @return 结果
     */
    @Override
    public int updateBanner(Banner banner)
    {
        banner.setUpdateTime(DateUtils.getNowDate());
        return bannerMapper.updateBanner(banner);
    }

    /**
     * 批量删除banner
     * 
     * @param bannerTabIds 需要删除的bannerID
     * @return 结果
     */
    @Override
    public int deleteBannerByIds(Long[] bannerTabIds)
    {
        return bannerMapper.deleteBannerByIds(bannerTabIds);
    }

    /**
     * 删除banner信息
     * 
     * @param bannerTabId bannerID
     * @return 结果
     */
    @Override
    public int deleteBannerById(Long bannerTabId)
    {
        return bannerMapper.deleteBannerById(bannerTabId);
    }
}
