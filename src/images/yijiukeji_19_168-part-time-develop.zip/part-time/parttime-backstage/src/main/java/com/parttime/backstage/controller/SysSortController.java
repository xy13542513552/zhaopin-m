package com.parttime.backstage.controller;

import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.parttime.common.annotation.Log;
import com.parttime.common.core.controller.BaseController;
import com.parttime.common.core.domain.AjaxResult;
import com.parttime.common.enums.BusinessType;
import com.parttime.backstage.domain.SysSort;
import com.parttime.backstage.service.ISysSortService;
import com.parttime.common.utils.poi.ExcelUtil;
import com.parttime.common.core.page.TableDataInfo;

/**
 * 分类Controller
 * 
 * @author parttime
 * @date 2021-05-26
 */
@RestController
@RequestMapping("/parttime-backstage/sort")
public class SysSortController extends BaseController
{
    @Autowired
    private ISysSortService sysSortService;

    /**
     * 查询分类列表
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:sort:list')")
    @GetMapping("/list")
    public AjaxResult list(SysSort sysSort)
    {
        List<SysSort> list = sysSortService.selectSysSortList(sysSort);
        return AjaxResult.success(list);
    }

    /**
     * 导出分类列表
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:sort:export')")
    @Log(title = "分类", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(SysSort sysSort)
    {
        List<SysSort> list = sysSortService.selectSysSortList(sysSort);
        ExcelUtil<SysSort> util = new ExcelUtil<SysSort>(SysSort.class);
        return util.exportExcel(list, "分类数据");
    }

    /**
     * 获取分类详细信息
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:sort:query')")
    @GetMapping(value = "/{sortId}")
    public AjaxResult getInfo(@PathVariable("sortId") Long sortId)
    {
        return AjaxResult.success(sysSortService.selectSysSortById(sortId));
    }

    /**
     * 新增分类
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:sort:add')")
    @Log(title = "分类", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysSort sysSort)
    {
        return toAjax(sysSortService.insertSysSort(sysSort));
    }

    /**
     * 修改分类
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:sort:edit')")
    @Log(title = "分类", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysSort sysSort)
    {
        return toAjax(sysSortService.updateSysSort(sysSort));
    }

    /**
     * 删除分类
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:sort:remove')")
    @Log(title = "分类", businessType = BusinessType.DELETE)
	@DeleteMapping("/{sortIds}")
    public AjaxResult remove(@PathVariable Long[] sortIds)
    {
        return toAjax(sysSortService.deleteSysSortByIds(sortIds));
    }
}
