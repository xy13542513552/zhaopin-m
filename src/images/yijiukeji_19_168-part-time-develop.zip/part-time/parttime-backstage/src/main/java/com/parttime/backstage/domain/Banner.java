package com.parttime.backstage.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.parttime.common.annotation.Excel;
import com.parttime.common.core.domain.BaseEntity;

/**
 * banner对象 yj_banner_tab
 * 
 * @author parttime
 * @date 2021-05-26
 */
public class Banner extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** banner轮播图 */
    private Long bannerTabId;

    /** 轮播图 */
    @Excel(name = "轮播图")
    private String bannerImg;

    /** 轮播图链接地址 */
    @Excel(name = "轮播图链接地址")
    private String bannerImgAddress;

    /** 图片来源 */
    @Excel(name = "图片来源")
    private String imgSource;

    /** 序列 */
    @Excel(name = "序列")
    private Integer sequence;

    /** 是否启用 */
    @Excel(name = "是否启用")
    private Integer isStart;

    public void setBannerTabId(Long bannerTabId) 
    {
        this.bannerTabId = bannerTabId;
    }

    public Long getBannerTabId() 
    {
        return bannerTabId;
    }
    public void setBannerImg(String bannerImg) 
    {
        this.bannerImg = bannerImg;
    }

    public String getBannerImg() 
    {
        return bannerImg;
    }
    public void setBannerImgAddress(String bannerImgAddress) 
    {
        this.bannerImgAddress = bannerImgAddress;
    }

    public String getBannerImgAddress() 
    {
        return bannerImgAddress;
    }
    public void setImgSource(String imgSource) 
    {
        this.imgSource = imgSource;
    }

    public String getImgSource() 
    {
        return imgSource;
    }
    public void setSequence(Integer sequence) 
    {
        this.sequence = sequence;
    }

    public Integer getSequence() 
    {
        return sequence;
    }
    public void setIsStart(Integer isStart) 
    {
        this.isStart = isStart;
    }

    public Integer getIsStart() 
    {
        return isStart;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("bannerTabId", getBannerTabId())
            .append("bannerImg", getBannerImg())
            .append("bannerImgAddress", getBannerImgAddress())
            .append("imgSource", getImgSource())
            .append("sequence", getSequence())
            .append("isStart", getIsStart())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
