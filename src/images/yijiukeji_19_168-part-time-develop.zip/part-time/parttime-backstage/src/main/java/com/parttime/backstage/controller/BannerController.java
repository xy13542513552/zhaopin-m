package com.parttime.backstage.controller;

import java.util.List;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.parttime.common.annotation.Log;
import com.parttime.common.core.controller.BaseController;
import com.parttime.common.core.domain.AjaxResult;
import com.parttime.common.enums.BusinessType;
import com.parttime.backstage.domain.Banner;
import com.parttime.backstage.service.IBannerService;
import com.parttime.common.utils.poi.ExcelUtil;
import com.parttime.common.core.page.TableDataInfo;

/**
 * bannerController
 * 
 * @author parttime
 * @date 2021-05-26
 */
@RestController
@RequestMapping("/parttime-backstage/banner")
public class BannerController extends BaseController
{
    @Autowired
    private IBannerService bannerService;

    /**
     * 查询banner列表
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:banner:list')")
    @GetMapping("/list")
    public TableDataInfo list(Banner banner)
    {
        startPage();
        List<Banner> list = bannerService.selectBannerList(banner);
        return getDataTable(list);
    }

    /**
     * 导出banner列表
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:banner:export')")
    @Log(title = "banner", businessType = BusinessType.EXPORT)
    @GetMapping("/export")
    public AjaxResult export(Banner banner)
    {
        List<Banner> list = bannerService.selectBannerList(banner);
        ExcelUtil<Banner> util = new ExcelUtil<Banner>(Banner.class);
        return util.exportExcel(list, "banner数据");
    }

    /**
     * 获取banner详细信息
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:banner:query')")
    @GetMapping(value = "/{bannerTabId}")
    public AjaxResult getInfo(@PathVariable("bannerTabId") Long bannerTabId)
    {
        return AjaxResult.success(bannerService.selectBannerById(bannerTabId));
    }

    /**
     * 新增banner
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:banner:add')")
    @Log(title = "banner", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody Banner banner)
    {
        return toAjax(bannerService.insertBanner(banner));
    }

    /**
     * 修改banner
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:banner:edit')")
    @Log(title = "banner", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody Banner banner)
    {
        return toAjax(bannerService.updateBanner(banner));
    }

    /**
     * 删除banner
     */
    @PreAuthorize("@ss.hasPermi('parttime-backstage:banner:remove')")
    @Log(title = "banner", businessType = BusinessType.DELETE)
	@DeleteMapping("/{bannerTabIds}")
    public AjaxResult remove(@PathVariable Long[] bannerTabIds)
    {
        return toAjax(bannerService.deleteBannerByIds(bannerTabIds));
    }
}
